package bueno;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class main extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textName;
	private JTextField textage;
	private JLabel lblPrint;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFirstName = new JLabel("First Name:");
		lblFirstName.setBounds(12, 35, 73, 17);
		contentPane.add(lblFirstName);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textName.setText(null);
				textage.setText(null);
				lblPrint.setText(null);
			}
		});
		btnClear.setBounds(213, 224, 101, 27);
		contentPane.add(btnClear);
		
		JButton btnGenerate = new JButton("Generate");
		btnGenerate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = textName.getText();
				int age = Integer.parseInt(textage.getText());
				if (age > 18) {
					lblPrint.setText(""+name+"pwede na makulong!!!");
				}
				else {
					lblPrint.setText("your not in legal age!!!");
				}
			}
		});
		btnGenerate.setBounds(54, 224, 101, 27);
		contentPane.add(btnGenerate);
		
		textName = new JTextField();
		textName.setBounds(106, 33, 147, 21);
		contentPane.add(textName);
		textName.setColumns(10);
		
		JLabel lblage = new JLabel("Age:");
		lblage.setBounds(24, 69, 39, 17);
		contentPane.add(lblage);
		
		textage = new JTextField();
		textage.setBounds(106, 67, 147, 21);
		contentPane.add(textage);
		textage.setColumns(10);
		
		lblPrint = new JLabel("");
		lblPrint.setBounds(41, 128, 212, 46);
		contentPane.add(lblPrint);
	}
}
