<?php
// login.php - Handles teacher and student login
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

// Get user input
$userinfo = $_POST['userinfo'] ?? '';  // Email or LRN
$password = $_POST['password'] ?? '';

// Check if fields are empty
if (empty($userinfo) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Please fill in all fields']);
    exit;
}

// Identify whether input is email (teacher) or LRN (student)
if (filter_var($userinfo, FILTER_VALIDATE_EMAIL)) {
    $sql = "SELECT * FROM teachers WHERE Email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $userinfo);
    $role = 'teacher';
} else {
    $sql = "SELECT * FROM information WHERE LRN = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $userinfo);
    $role = 'student';
}

$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Verify password
    if (password_verify($password, $row['Password'])) {
        // Store session data
        $_SESSION['loggedInUser'] = $role === 'teacher' ? $row['Email'] : $row['LRN'];
        $_SESSION['role'] = $role;

        if ($role === 'teacher') {
            $_SESSION['teacherID'] = $row['TeacherID'];
            echo json_encode(['success' => true, 'message' => 'Teacher Login Successful']);
        } else {
            $_SESSION['studentID'] = $row['LRN'];
            echo json_encode(['success' => true, 'message' => 'Student Login Successful']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid Password']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'User not found']);
}

$stmt->close();
$conn->close();
?>
