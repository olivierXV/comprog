This is a test version of our program for our research titled
"SCHOOP: Development of a School E-Portal for SHS in San Nicolas III, Bacoor City."
